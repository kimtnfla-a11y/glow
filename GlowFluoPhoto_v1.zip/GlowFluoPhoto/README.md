# GlowFluo Photo

A standalone Android photo editor made for the custom **GlowFluo Skin Focus v2** look.

## What it does
- Pick a photo from the phone.
- Apply the built-in GlowFluo Skin Focus v2 look.
- Filter strength 0–100%.
- Hair and deep eye tones are protected from the high-key lift.
- Skin is lifted softly.
- Pink/red lip tones remain lively.
- Highlights are compressed to reduce the "everything is blown out" problem.
- Save edited JPEGs to `Pictures/GlowFluo`.

The LUT is embedded into the app as a 33×33×33 3D lookup table, so the APK does not need to read an external `.cube` file at runtime.

## Build
The included GitHub Actions workflow uses Java 17 and Gradle 8.11.1 and uploads the debug APK.
