package com.glowfluo.photo;

import android.graphics.Bitmap;
import android.graphics.Color;

public class LutFilter {
    private static final int N = 33;
    private final float[] lut = new float[N*N*N*3];

    public LutFilter() {
        buildGlowFluoSkinFocus();
    }

    /*
     * Built-in equivalent of GlowFluo_SkinFocus_v2:
     * - brightens mid/high tones gently
     * - protects deep blacks (hair/eyes)
     * - brightens warm skin tones
     * - keeps lips lively
     * - compresses highlights to avoid a blown-out look
     *
     * The app embeds the look so it does not depend on an external .cube file.
     */
    private void buildGlowFluoSkinFocus() {
        for (int b=0;b<N;b++) for (int g=0;g<N;g++) for (int r=0;r<N;r++) {
            float R=r/(N-1f), G=g/(N-1f), B=b/(N-1f);
            float lum=0.2126f*R+0.7152f*G+0.0722f*B;
            float mid=clamp((lum-0.16f)/0.70f,0,1);
            float lift=0.055f*(float)Math.pow(mid,1.35);
            float dark=clamp((0.20f-lum)/0.20f,0,1);
            R+=lift; G+=lift; B+=lift;
            R*=1-0.055f*dark; G*=1-0.055f*dark; B*=1-0.055f*dark;

            float[] hsv=rgbToHsv(R,G,B);
            float h=hsv[0], s=hsv[1], v=hsv[2];

            float warm=Math.max(
                    (float)Math.exp(-Math.pow(hueDist(h,0.055f)/0.075f,2)),
                    0.70f*(float)Math.exp(-Math.pow(hueDist(h,0.97f)/0.060f,2))
            );
            float skin=warm*clamp((s-0.04f)/0.62f,0,1)*clamp((v-0.18f)/0.72f,0,1);
            float skinLift=0.105f*skin*(0.9f-0.25f*v);
            R+=skinLift; G+=skinLift; B+=skinLift;

            hsv=rgbToHsv(R,G,B);
            h=hsv[0]; s=clamp(hsv[1]*(1-0.10f*skin),0,1); v=hsv[2];
            h=(h+0.006f*skin)%1f;

            float red=Math.max(
                    (float)Math.exp(-Math.pow(hueDist(h,0.0f)/0.045f,2)),
                    (float)Math.exp(-Math.pow(hueDist(h,0.965f)/0.045f,2))
            );
            float lips=red*clamp((s-0.32f)/0.60f,0,1)*clamp((v-0.22f)/0.65f,0,1);
            s=clamp(s+0.10f*lips,0,1);
            v=clamp(v+0.025f*lips,0,1);

            float[] rgb=hsvToRgb(h,s,v);
            R=rgb[0]; G=rgb[1]; B=rgb[2];

            R=highlightCompress(R); G=highlightCompress(G); B=highlightCompress(B);
            int idx=index(r,g,b);
            lut[idx]=clamp(R,0,1);
            lut[idx+1]=clamp(G,0,1);
            lut[idx+2]=clamp(B,0,1);
        }
    }

    public Bitmap apply(Bitmap src, float strength) {
        Bitmap out=src.copy(Bitmap.Config.ARGB_8888,true);
        int w=out.getWidth(), h=out.getHeight();
        int[] px=new int[w*h];
        out.getPixels(px,0,w,0,0,w,h);
        for(int i=0;i<px.length;i++){
            int c=px[i];
            float[] graded = sample(Color.red(c)/255f, Color.green(c)/255f, Color.blue(c)/255f);
            float r=graded[0], g=graded[1], b=graded[2];
            int rr=Math.round(255*(Color.red(c)/255f*(1-strength)+r*strength));
            int gg=Math.round(255*(Color.green(c)/255f*(1-strength)+g*strength));
            int bb=Math.round(255*(Color.blue(c)/255f*(1-strength)+b*strength));
            px[i]=Color.argb(Color.alpha(c),clamp255(rr),clamp255(gg),clamp255(bb));
        }
        out.setPixels(px,0,w,0,0,w,h);
        return out;
    }

    private float[] sample(float R, float G, float B){
        float xr=R*(N-1), yg=G*(N-1), zb=B*(N-1);
        int r0=(int)Math.floor(xr), r1=Math.min(N-1,r0+1);
        int g0=(int)Math.floor(yg), g1=Math.min(N-1,g0+1);
        int b0=(int)Math.floor(zb), b1=Math.min(N-1,b0+1);
        float tr=xr-r0, tg=yg-g0, tb=zb-b0;
        float[] out=new float[3];
        for(int ch=0; ch<3; ch++){
            float c000=lut[index(r0,g0,b0)+ch], c100=lut[index(r1,g0,b0)+ch];
            float c010=lut[index(r0,g1,b0)+ch], c110=lut[index(r1,g1,b0)+ch];
            float c001=lut[index(r0,g0,b1)+ch], c101=lut[index(r1,g0,b1)+ch];
            float c011=lut[index(r0,g1,b1)+ch], c111=lut[index(r1,g1,b1)+ch];
            float a=lerp(c000,c100,tr), b=lerp(c010,c110,tr);
            float d=lerp(c001,c101,tr), e=lerp(c011,c111,tr);
            out[ch]=lerp(lerp(a,b,tg),lerp(d,e,tg),tb);
        }
        return out;
    }

    private int index(int r,int g,int b){ return ((b*N+g)*N+r)*3; }
    private float lerp(float a,float b,float t){return a+(b-a)*t;}
    private float clamp(float v,float a,float b){return Math.max(a,Math.min(b,v));}
    private int clamp255(int v){return Math.max(0,Math.min(255,v));}
    private float hueDist(float a,float b){float d=Math.abs(a-b);return Math.min(d,1-d);}
    private float highlightCompress(float x){return x>0.90f ? 0.90f+(x-0.90f)*0.45f : x;}

    private float[] rgbToHsv(float r,float g,float b){
        float mx=Math.max(r,Math.max(g,b)), mn=Math.min(r,Math.min(g,b)), d=mx-mn;
        float h=0;
        if(d>1e-7){
            if(mx==r) h=((g-b)/d)%6f;
            else if(mx==g) h=(b-r)/d+2f;
            else h=(r-g)/d+4f;
            h/=6f; if(h<0)h+=1f;
        }
        float s=mx<1e-7?0:d/mx;
        return new float[]{h,s,mx};
    }

    private float[] hsvToRgb(float h,float s,float v){
        float hh=h*6f, f=hh-(float)Math.floor(hh);
        int i=((int)Math.floor(hh))%6;
        float p=v*(1-s), q=v*(1-s*f), t=v*(1-s*(1-f));
        switch(i){
            case 0:return new float[]{v,t,p};
            case 1:return new float[]{q,v,p};
            case 2:return new float[]{p,v,t};
            case 3:return new float[]{p,q,v};
            case 4:return new float[]{t,p,v};
            default:return new float[]{v,p,q};
        }
    }
}
