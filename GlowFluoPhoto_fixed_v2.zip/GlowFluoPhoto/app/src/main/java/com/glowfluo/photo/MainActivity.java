package com.glowfluo.photo;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private ImageView imageView;
    private TextView status;
    private SeekBar strengthBar;
    private Bitmap original;
    private Bitmap preview;
    private final LutFilter lut = new LutFilter();

    private final ActivityResultLauncher<String> picker =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri == null) return;

                try {
                    Bitmap full = decodeBitmap(uri);
                    if (full == null) throw new Exception("decode failed");

                    Bitmap scaled = makePreview(full, 1800);
                    if (scaled != full && !full.isRecycled()) {
                        full.recycle();
                    }

                    replaceOriginal(scaled);
                    strengthBar.setProgress(100);
                    render();
                } catch (Exception e) {
                    Toast.makeText(this, "사진을 불러오지 못했어요.", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(buildUi());
    }

    @Override
    protected void onDestroy() {
        if (preview != null && preview != original && !preview.isRecycled()) {
            preview.recycle();
        }
        if (original != null && !original.isRecycled()) {
            original.recycle();
        }
        super.onDestroy();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 18, 18, 12);
        root.setBackgroundColor(Color.rgb(18, 16, 20));

        TextView title = new TextView(this);
        title.setText("GlowFluo Photo");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 6, 0, 8);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        status = new TextView(this);
        status.setText("사진을 선택하세요");
        status.setTextColor(Color.rgb(230, 220, 230));
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        imageView = new ImageView(this);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setBackgroundColor(Color.rgb(8, 8, 10));
        root.addView(imageView, new LinearLayout.LayoutParams(-1, 0, 1f));

        TextView label = new TextView(this);
        label.setText("필터 강도");
        label.setTextColor(Color.WHITE);
        label.setPadding(4, 8, 4, 0);
        root.addView(label);

        strengthBar = new SeekBar(this);
        strengthBar.setMax(100);
        strengthBar.setProgress(100);
        strengthBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean fromUser) {
                if (original != null) {
                    status.setText(String.format(Locale.US,
                            "GlowFluo Skin Focus • %d%%", p));
                    render();
                }
            }

            public void onStartTrackingTouch(SeekBar b) {}

            public void onStopTrackingTouch(SeekBar b) {}
        });
        root.addView(strengthBar);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);

        Button open = new Button(this);
        open.setText("사진 선택");
        open.setOnClickListener(v -> picker.launch("image/*"));

        Button reset = new Button(this);
        reset.setText("원본");
        reset.setOnClickListener(v -> {
            if (original != null && !original.isRecycled()) {
                imageView.setImageBitmap(original);
                status.setText("원본");
            }
        });

        Button save = new Button(this);
        save.setText("저장");
        save.setOnClickListener(v -> saveImage());

        buttons.addView(open, new LinearLayout.LayoutParams(0, -2, 1));
        buttons.addView(reset, new LinearLayout.LayoutParams(0, -2, 1));
        buttons.addView(save, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(buttons);

        return root;
    }

    private void replaceOriginal(Bitmap bitmap) {
        if (preview != null && preview != original && !preview.isRecycled()) {
            preview.recycle();
        }

        if (original != null && !original.isRecycled()) {
            original.recycle();
        }

        original = bitmap;
        preview = null;
        imageView.setImageBitmap(original);
        status.setText("GlowFluo Skin Focus • 100%");
    }

    private Bitmap decodeBitmap(Uri uri) throws Exception {
        ContentResolver cr = getContentResolver();
        try (InputStream in = cr.openInputStream(uri)) {
            return BitmapFactory.decodeStream(in);
        }
    }

    private Bitmap makePreview(Bitmap src, int max) {
        int w = src.getWidth();
        int h = src.getHeight();
        float scale = Math.min(1f, max / (float) Math.max(w, h));

        if (scale >= 1f) {
            return src;
        }

        int nw = Math.max(1, Math.round(w * scale));
        int nh = Math.max(1, Math.round(h * scale));
        return Bitmap.createScaledBitmap(src, nw, nh, true);
    }

    private void render() {
        if (original == null || original.isRecycled()) return;

        final Bitmap source = original;
        final float strength = strengthBar.getProgress() / 100f;

        new Thread(() -> {
            Bitmap out = null;

            try {
                out = lut.apply(source, strength);
            } catch (Exception ignored) {
                return;
            }

            final Bitmap result = out;

            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) {
                    if (result != null && !result.isRecycled()) result.recycle();
                    return;
                }

                if (source != original || original == null || original.isRecycled()) {
                    if (result != null && !result.isRecycled()) result.recycle();
                    return;
                }

                Bitmap old = preview;
                preview = result;
                imageView.setImageBitmap(result);

                if (old != null && old != original && old != result && !old.isRecycled()) {
                    old.recycle();
                }
            });
        }).start();
    }

    private void saveImage() {
        if (original == null || original.isRecycled()) {
            Toast.makeText(this, "먼저 사진을 선택하세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        final Bitmap source = original;
        final float strength = strengthBar.getProgress() / 100f;

        new Thread(() -> {
            Bitmap out = null;
            Uri uri = null;

            try {
                out = lut.apply(source, strength);

                String name = "GlowFluo_" + System.currentTimeMillis() + ".jpg";
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                cv.put(MediaStore.Images.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_PICTURES + "/GlowFluo");

                uri = getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);

                if (uri == null) throw new Exception("insert failed");

                try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                    if (os == null) throw new Exception("output stream failed");
                    if (!out.compress(Bitmap.CompressFormat.JPEG, 96, os)) {
                        throw new Exception("compress failed");
                    }
                }

                runOnUiThread(() ->
                        Toast.makeText(this, "갤러리에 저장했어요.",
                                Toast.LENGTH_SHORT).show());

            } catch (Exception e) {
                if (uri != null) {
                    getContentResolver().delete(uri, null, null);
                }

                runOnUiThread(() ->
                        Toast.makeText(this, "저장에 실패했어요.",
                                Toast.LENGTH_SHORT).show());

            } finally {
                if (out != null && !out.isRecycled()) {
                    out.recycle();
                }
            }
        }).start();
    }
}
